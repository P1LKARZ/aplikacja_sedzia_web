import React, { useState } from "react";
import { collection, addDoc } from "firebase/firestore";
import { db, auth } from "../../../firebase";
import { useMeczFormData } from "../useMeczFormData";
import { Team } from "../Team/Team";
import { League } from "../League/League";
import { Details } from "../Details/Details";
import "./MeczForm.css";
import { generatePDF as generatePdfFile } from "../../../utils/generatePdf";
import { mapMeczToPdfData } from "../../../utils/mapMeczToPdfData";
import { getRundaSezon } from "../../../utils/getRundaSezon";

function todayDate() {
  const today = new Date();
  return `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;
}

export default function MeczForm() {
  const [gospodarz, setGospodarz] = useState("");
  const [gosc, setGosc] = useState("");
  const [liga, setLiga] = useState("");
  const [kasa, setKasa] = useState("");
  const [podatek, setPodatek] = useState("");
  const [sedzia, setSedzia] = useState("");
  const [data, setData] = useState(todayDate);
  const [numerMeczu, setNumerMeczu] = useState("");
  const [delegacja, setDelegacja] = useState(0);
  const [zaplacone, setZaplacone] = useState("");
  const [loading, setLoading] = useState(false);

  const {
    druzyny,
    poziomy,
    sedziowie,
    loading: dataLoading,
    error,
    validateForm,
  } = useMeczFormData();

  const handleLigaChange = (e) => {
    const value = e.target.value;
    setLiga(value);
    const selected = poziomy.find((p) => p.nazwa === value);
    setKasa(selected?.kasa ?? "");
    setPodatek(selected?.podatek ?? "");
  };

  const handleGospodarzChange = (e) => {
    const value = e.target.value;
    setGospodarz(value);

    const team = druzyny.find((d) => d.nazwa === value);

    if (team?.platnosc === "delegacja") {
      setDelegacja(1);
      setZaplacone("T");
    } else if (team?.platnosc === "edelegacja") {
      setDelegacja(0);
      setZaplacone("N");
    } else {
      // Jeśli płatność nie jest delegacją, nie generujemy delegacji
      setDelegacja(0);
      setZaplacone("");
    }
  };

  const resetForm = () => {
    setGospodarz("");
    setGosc("");
    setLiga("");
    setKasa("");
    setPodatek("");
    setSedzia("");

    setData(todayDate());

    setNumerMeczu("");
    setDelegacja(0);
    setZaplacone("");
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Walidacja formularza
    const formData = {
      gospodarz,
      gosc,
      liga,
      sedzia,
      data,
      numerMeczu,
    };

    const emptyFields = validateForm(formData);

    if (emptyFields.length > 0) {
      const fieldsList = emptyFields.join(", ");
      alert(`❌ Wypełnij brakujące pola:\n\n${fieldsList}`);
      return;
    }

    const user = auth.currentUser;

    if (!user) {
      alert("❌ Nie jesteś zalogowany");
      return;
    }

    setLoading(true);

    const { runda, sezon } = getRundaSezon(data);

    const mecz = {
      id_mecz: crypto.randomUUID(),
      gospodarz,
      gosc,
      liga,
      kasa,
      podatek,
      data,
      glowny: sedzia,
      numer_meczu: numerMeczu,
      delegacja,
      zaplacone,
      runda,
      sezon,
      // Pola wyników - puste przy dodawaniu
      wynikGospodarz: null,
      wynikGosc: null,
      zolteKartkiGospodarz: 0,
      zolteKartkiGosc: 0,
      czerwoneKartkiGospodarz: 0,
      czerwoneKartkiGosc: 0,
      createdAt: new Date().toISOString(),
    };

    try {
      await addDoc(collection(db, "users", user.uid, "mecze"), mecz);
      alert("✅ Mecz dodany!");
      const pdfData = mapMeczToPdfData(mecz);
      generatePdfFile(pdfData);
      resetForm();
    } catch (err) {
      console.error(err);
      alert(
        `❌ Błąd podczas zapisu meczu:\n${err.message || "Spróbuj ponownie"}`,
      );
    } finally {
      setLoading(false);
    }
  };

  if (dataLoading) {
    return (
      <div className="loading-container">
        <div className="spinner"></div>
        <p>Ładowanie danych…</p>
      </div>
    );
  }
  const sortedDruzyny = [...druzyny].sort((a, b) =>
    a.nazwa.localeCompare(b.nazwa, "pl"),
  );
  return (
    <div className="mecz-form-container">
      <div className="form-header">
        <h1 className="form-title">Dodaj mecz</h1>
        <p className="form-subtitle">
          Zacznij od drużyn, wybierz ligę i uzupełnij szczegóły.
        </p>
      </div>

      {error && <div className="error-alert">{error}</div>}

      <form onSubmit={handleSubmit} className="mecz-form">
        <Team
          druzyny={sortedDruzyny}
          gospodarz={gospodarz}
          gosc={gosc}
          onGospodarzChange={handleGospodarzChange}
          onGoscChange={setGosc}
        />

        <League
          poziomy={poziomy}
          liga={liga}
          kasa={kasa}
          podatek={podatek}
          onLigaChange={handleLigaChange}
        />

        <Details
          sedziowie={sedziowie}
          sedzia={sedzia}
          data={data}
          numerMeczu={numerMeczu}
          zaplacone={zaplacone}
          onSedziaChange={setSedzia}
          onDataChange={setData}
          onNumerMeczuChange={setNumerMeczu}
        />

        <div className="form-actions">
          <button type="submit" className="btn-submit" disabled={loading}>
            <span>{loading ? "Zapisywanie..." : "Zapisz mecz"}</span>
            <div className="btn-shimmer"></div>
          </button>
          <button
            type="button"
            className="btn-reset"
            onClick={resetForm}
            disabled={loading}
          >
            Anuluj
          </button>
        </div>
      </form>
    </div>
  );
}
